package testcases;


import org.testng.annotations.Test;
import extentlisteners.Listeners;

public class BannerValidation extends Listeners{
	@Test
	public void ValidateBanners() throws InterruptedException {	
//		bp.ClickOnEachBanner();
//		bp.GetBanner();
//		reportEvent("PASS","Validated First Banner successfully ",true);
//		bp.GetBanner2();
//		reportEvent("PASS","Validated Second Banner successfully ",true);
//		bp.GetBanner3();
//		reportEvent("PASS","Validated Third Banner successfully ",true);
//		bp.GetBanner4();
//		bp.GetBanner5(); 
		
	}

}
